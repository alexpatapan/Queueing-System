import tkinter as tk
from tkinter import messagebox
import time
from functools import partial
import random

class Header(tk.Frame):
    """
    A frame to store the top banner section.
    """
    
    def __init__(self, root):
        """
        Initialise the widget, with its subwidgets
        """
        super().__init__(root)
        longtext = ('\nIndividual assessment items must be solely your own work. '
                    'While students are encouraged to have high-level conversations about the problems '
                    'they are trying to solve, you must not look at another student\'s code or copy from it. '
                    'The university uses sophisticated anti-collusion measures to automatically detect similarity ' 
                    'between assignment submissions.')
        self._plagiarism = tk.Text(self, wrap='word', font=('Calibri', 12), bg='light yellow', highlightthickness=0, height=7, borderwidth=0)
        self._plagiarism.pack(anchor = tk.W, padx=20, fill=tk.X)
        self._plagiarism.tag_configure("bold", font="Calibri 15 bold", spacing1=15, spacing3=8, foreground='goldenrod')
        self._plagiarism.insert('1.0', 'Important', 'bold')
        self._plagiarism.insert('4.0', longtext)
        self._plagiarism.config(state='disabled')

class Row(object):
    """
    A class to store each instance of a row in the queue.
    """
    
    def __init__(self, master, table, name, questions_asked, header= False):
        """
        Initialise the widget, with its subwidgets

        Parameters:
            master (Question): Generic superclass for Quick/Long queues 
            table (tk.Frame): Frame to put row into
            name (string): Name of person / Column title 
            questions_asked (int): Number of questions previously asked (if any)
            header (boolean): Check whether row is a table header or storing a person in the queue
        """
        row_number = int(not(header))
        self.master = master
        self.number = tk.Label(table, bg='white')
        self.name = tk.Label(table, text=name, anchor=tk.W, bg='white', width=20)
        self.question = tk.Label(table, bg='white')
        self.time = tk.Label(table, bg='white')
        self.number.grid(row=row_number, column=0)
        self.name.grid(row=row_number, column=1, columnspan=10)
        self.question.grid(row=row_number, column=2)
        self.time.grid(row=row_number, column=3, sticky=tk.W, padx=(20,150))

        if header:
            fontstyle='Calibri 13 bold'
            self.name.grid(padx=(6,0), ipady=5, sticky=tk.W)
            self.number.config(font=fontstyle, text='#')
            self.name.config(font=fontstyle)
            self.time.config(font=fontstyle, text='Time')
            self.question.config(text='Questions Asked', font=fontstyle)
        else:
            fontstyle='Calibri 12'
            self.name.config(width=23, font=fontstyle)
            self.name.grid(padx=(6,0), sticky=tk.W+tk.E+tk.N+tk.S)
            self.number.config(text='1', font=fontstyle)
            self.cancel_btn = tk.Button(table, bg='salmon', width=2, command=self.generic_press,highlightcolor='brown1', highlightbackground='red')
            self.cancel_btn.grid(row=row_number, column= 4)
            self.completed_btn = tk.Button(table, bg='palegreen3', width=2, command=self.completed_press, highlightbackground='palegreen3')
            self.completed_btn.grid(row=row_number, column = 5)
            self.time.config(text='a few seconds ago', font=fontstyle, width=15, anchor=tk.W)
            self.time.grid(padx=15)
            self.questioncount = questions_asked
            self.question.config(text=questions_asked, font=fontstyle)
            self.question.grid(row=row_number, padx=(0,118))
            self.start_time = time.time()
            self.total_minutes = 0
            self.master.master.activeperson.append(name)

    def completed_press(self):
        """
        Called upon clicking Completed button. 
        """
        self.question.config(text=self.questioncount+1)
        self.generic_press()
        
    def generic_press(self):
        """
        Generic button function removing person and reordering list.
        """        
        currentrow = self.question.grid_info()['row']
        for widget in [self.question, self.name, self.number,
        self.time, self.completed_btn, self.cancel_btn]:
            widget.grid_remove()
        name = self.name.cget('text')
        self.master.hiddenpeople[name] = self.master.people[name]
        del self.master.people[name]
        self.master.master.activeperson.remove(name)
        self.master.multi_shift(-1, currentrow)  

class Question(tk.Frame):
    """
    Generic Frame for Quick and Long Question queue.
    """
    
    def __init__(self, master, question_type):
        """
        Initialise the widget, with its subwidgets.

        Parameters:
            master (object): Main app class which Question instance belongs to
            question_type (string): specifies the type of Question frame
        """
        super().__init__()
        self.hiddenpeople = {}
        self.master = master
        self.people = {}
        self.pack(side=tk.LEFT, expand=1, fill=tk.X, anchor=tk.N, padx=15, pady=15)
        self.config(bg='gray76')
        #queueheader contains colouredframe, examples and helpbtn
        self._averageheader = tk.Frame(self, bg='white', borderwidth=0)
        self._averageheader.pack(expand=1, fill=tk.BOTH)
        self._colouredframe = tk.Frame(self._averageheader)
        self._colouredframe.pack(anchor=tk.N, fill=tk.X)
        self._helpbtn = tk.Button(self._averageheader, text='Request {} Help'.format(question_type), height=2, fg='white', relief='flat',
            command= self.help_window, borderwidth=1, highlightthickness=1)
        self._helpbtn.pack(side=tk.BOTTOM, ipadx=8, pady=10)
        self._title = tk.Label(self._colouredframe, text= question_type+' Questions', font="Calibri 22 bold")
        self._title.pack(pady=10)
        self._tutortime = tk.Label(self._colouredframe, fg='gray', font='Calibri 11')
        self._tutortime.pack(side=tk.BOTTOM, pady=10)
        self._examples = tk.Text(self._averageheader, font=('Calibri', 11), width=40, borderwidth=0, highlightthickness=0, spacing1=5)
        self._examples.pack(side=tk.LEFT, anchor=tk.N, pady=5, fill=tk.X, expand=1)
        self._examples.tag_configure('dotpoint', lmargin1=10, lmargin2=10)
        self._examples.insert('1.0', 'Some examples of {} questions:'.format(question_type.lower()))
         
        self._averageframe = tk.Frame(self, bg='white')
        self._average = tk.Label(self._averageframe, text='No students in queue.', font='Calibri 12', anchor=tk.W, bg='white')
        self._averageframe.pack(side=tk.TOP, pady=1, ipady=25, fill=tk.BOTH, expand=1)
        self._averageframe.pack_propagate(False)
        self._average.pack(side=tk.LEFT, fill=tk.BOTH)
        
        self._tableheaderframe = tk.Frame(self, bg='white')
        self._tableheaderframe.pack(side=tk.TOP, fill=tk.BOTH, expand=1, pady=(0,1))
        self._tableheader = Row(self, self._tableheaderframe, 'Name', 0, True)
        self._tableheaderframe.columnconfigure(1, weight=1)
        self._tableframe = tk.Frame(self, height=30)
        self._tableframe.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=1)
        self._table = tk.Frame(self._tableframe, bg='white')
        self._table.pack(side=tk.BOTTOM, expand=1, fill=tk.BOTH)
        self._table.columnconfigure(1, weight=1)
        
    def help_window(self):
        """
        Create a popup for user to input name.
        """
        self._popup = Popup()
        self._popup.title('Input Name')
        self._popup.label.config(text='What is your name?')
        self._popup.button.config(command=self.check_valid_input)
        self._popup.bind('<Return>', self.check_valid_input)
        
    def check_valid_input(self, event=None):
        """
        Check if user has input a valid name.

        Parameters:
            event (Event): Event handler for <Return> keypress
        """
        name = self._popup.entry.get()
        if name in self.master.activeperson:
            messagebox.showerror("Invalid name", "Please enter a different name. \nThe name \'"+ name+'\' is already in use')
            self._popup.entry.delete(0, 'end')
        elif not name:
            messagebox.showerror("Invalid name", "Please enter a name")
        else:
            self.add_row(name)
    
    def add_row(self, name):
        """
        Add an additional row to the list frame.

        Parameters:
            name (string): The name of the person in the new row
        """
        if name in self.people:
            self.people[name].questioncount += 1
            self.people[name].question.config(text=self.people[name].questioncount)      
        else:
            if name in self.hiddenpeople:
                if self.people:
                    self.multi_shift(1)
                self.people[name] = self.hiddenpeople[name]
                del self.hiddenpeople[name]
                questions_asked = self.people[name].question.cget('text')
            else:
                questions_asked=0
                if self.people:
                    self.multi_shift(1)
                else:
                    self.timer() 
            self.people[name] = Row(self, self._table, name, questions_asked)      
        self.reorder(name) 
        self._popup.destroy()

    def multi_shift(self, amount, restriction=0):
        """
        Shift all rows of queue down by given amount.

        Parameters:
            amount (int): The number of rows to shift by
            restriction (int): Row numbers <= to this value will be unaffected by the shift 
        """
        self.average()
        for key in self.people:
            currentrow = self.people[key].question.grid_info()['row']
            if currentrow > restriction:
                self.single_shift(key, amount)
                

    def single_shift(self, row, amount):
        """
        Shift a single row by given amount.

        Parameters:
            row (string): The name of the person to shift
            amount (int): The number of rows to shift by
        """
        currentrow = self.people[row].question.grid_info()['row']
        for widget in [self.people[row].question, self.people[row].name, self.people[row].number,
        self.people[row].time, self.people[row].completed_btn, self.people[row].cancel_btn]:
            widget.grid(row=currentrow+amount)    
        self.people[row].number.config(text=currentrow+amount)
        
    def reorder(self, name):
        """
        Given a row, place it in correct order in the queue.

        Parameters:
            name (string): Name of person being ordered
        """
        currentrow = self.people[name].question.grid_info()['row']
        need_shift=True
        last_row= int(self.people[name].question.grid_info()['row'])
        
        while need_shift == True:
            for key in self.people:
                if last_row < int(self.people[key].question.grid_info()['row']):
                        last_row = int(self.people[key].question.grid_info()['row'])     
            for key in self.people:          
                if self.people[key].question.grid_info()['row'] == currentrow + 1:
                    if int(self.people[name].question.cget('text')) >= int(self.people[key].question.cget('text')):
                        self.single_shift(name, 1)
                        self.single_shift(key, -1)
                        currentrow += 1
                        break
                    else:
                        need_shift = False
                else:
                    if last_row == int(self.people[name].question.grid_info()['row']): 
                        need_shift = False   
        self.average()

    def timer(self):
        """
        Roughly every 10 seconds check to see if wait time needs to be updated.
        """
        for a in self.people:
            self.people[a].minutes = int(time.time() - self.people[a].start_time) // 60
            self.people[a].time.config(text = self.time_conversion(self.people[a].minutes)+ ' ago')
            self.people[a].total_minutes = self.people[a].minutes
        self.average()
        self.after(10000, self.timer)   
    
    def average(self):
        """
        Find average wait time and display it.
        """
        total_wait = 0
        for name in self.people:
            total_wait += self.people[name].total_minutes
        people_count = len(self.people)
        
        try:
            average_wait = int(total_wait / people_count)
            if average_wait:
                wait_time = 'about '
            else:
                wait_time = ''
            self._average.config(text='An average wait time of {} for {} student.'.format(wait_time+self.time_conversion(average_wait), str(people_count)))
            if people_count > 1:
                status = self._average.cget('text')[:-1]
                self._average.config(text = status + 's.')
        except ZeroDivisionError:
            self._average.config(text='No students in queue.')

    def time_conversion(self, time):
        """
        Convert time from integer format to string, with appropriate units.

        Parameters:
        time (int): time in minutes

        Returns:
            (string): the length of time in string format with units
        """
        if time >= 120:
            status = str(time//60) + ' hours'
        elif 60 <= time < 120:
            status = '1 hour'
        elif 2 <= time < 60:
            status = str(time) + ' minutes'
        elif 1 <= time < 2:
            status = 'a minute'
        else:
            status = 'a few seconds'
        return status
        

class QuickQuestion(Question):
    """
    Class to specify unique attributes to the quick question frame.
    """
    
    def __init__(self, master):
        """
        Add unique text and colours to widgets.
        """
        super().__init__(master, 'Quick')
        self._colouredframe.config(bg='darkseagreen1')
        self._title.config(fg='green', bg=self._colouredframe.cget('bg'))
        self._tutortime.config(text='< 2 mins with a tutor', bg=self._colouredframe.cget('bg'))
        exampletext= ('\n \u2022 Syntax errors'
                      '\n \u2022 Interpreting error output'
                      '\n \u2022 Assignment/MyPyTutor interpretation'
                      '\n \u2022 MyPyTutor submission issues')
        self._examples.insert('2.0', exampletext, 'dotpoint')
        self._examples.config(state='disabled', height=5)
        self._helpbtn.config(bg='palegreen3', activebackground='palegreen3', highlightbackground='green')
        
class LongQuestion(Question):
    """
    Class to specify unique attributes to the long question frame.
    """

    def __init__(self, master):
        """
        Add unique text and colours to widgets.
        """
        super().__init__(master, 'Long')
        self._colouredframe.config(bg='lightblue2')
        self._title.config(fg='steelblue4', bg=self._colouredframe.cget('bg'))
        self._tutortime.config(text='> 2 mins with a tutor', bg=self._colouredframe.cget('bg'))
        exampletext= ('\n \u2022 Open ended questions'
                      '\n \u2022 How to start a problem'
                      '\n \u2022 How to improve code'
                      '\n \u2022 Debugging'
                      '\n \u2022 Assignment help')
        self._examples.insert('2.0', exampletext, 'dotpoint')
        self._examples.config(state='disabled', height=6)
        self._helpbtn.config(highlightbackground='deepskyblue2', bg='lightblue2', activebackground='lightblue2') 

class Popup(tk.Toplevel):
    """
    Create a generic popup for user to input text.
    """
    
    def __init__(self):
        """
        Create generic widgets.
        """
        super().__init__()
        self.label = tk.Label(self)
        self.label.pack(side=tk.LEFT)
        self.entry = tk.Entry(self)
        self.entry.pack(side=tk.LEFT)
        self.button = tk.Button(self, text='Enter', width=10)
        self.button.pack(side=tk.LEFT)
        self.entry.focus_set()

class Game(tk.Toplevel):
    """
    A game of tic-tac-toe.
    """
    
    def __init__(self):
        """
        Initialise widgets.
        """
        super().__init__()
        self.title('Tic-Tac-Toe')
        self.geometry('400x400')
        self._board = tk.Frame(self, borderwidth=1)
        self._board.pack(fill=tk.BOTH, expand=1)
        self._board.grid_propagate(False)
        self._menu = tk.Menu(self)
        self.config(menu=self._menu)
        self._filemenu = tk.Menu(self._menu)
        self._menu.add_cascade(label="File", menu=self._filemenu)
        self._filemenu.add_command(label="New Game", command=self.reset_board)
        self._colourmenu = tk.Menu(self._filemenu)
        self._filemenu.add_cascade(label="Options", menu = self._colourmenu)
        self.user = Player('red', 'Player')
        self.computer = Player('deep sky blue', 'Computer')
        for player in [self.user, self.computer]:            
            self._colourmenu.add_command(label='Change {} colour'.format(player.name), command = partial(self.create_popup, player))
        for a in range(0,3):
            self._board.columnconfigure(a, weight=1)
            self._board.rowconfigure(a, weight=1)   
        self._replay = tk.Label(self)
        self._replay.pack(side=tk.RIGHT, anchor=tk.E)
        self._win = tk.Label(self, text='Current streak: None')
        self._win.pack(side=tk.LEFT, anchor=tk.W)

        self.finished = False
        self.turns=0
        self.streak = [None,0]
        self.starter = False
        self.reset_board()

    def reset_board(self):
        """
        Reset board to its default state
        """
        self._replay.config(text= '')
        if self.finished == False:
            self._win.config(text='Current Streak: None')
            self.streak = [None,0]
        self.tile = []
        self.turns = 0
        btn_id = 0
        self.finished = False
        for a in range(0,3):
            for b in range(0,3):
                self.tile.append(tk.Button(self._board, borderwidth=5, relief='sunken', state='normal', width=30, height=30, command= partial(self.on_click, btn_id)))
                self.tile[btn_id].grid(row=a, column= b, sticky=tk.N+tk.S+tk.E+tk.W)
                self.tile[btn_id].config(bg='white', activebackground='white')
                btn_id +=1
        if self.starter:
            self.computer_turn()

    def on_click(self, btn_id):
        """
        Called upon a tile being pressed.

        Parameters:
            btn_id (int) : unique identifier for the tile pressed
        """
        if self.finished == True:
            self.starter = not(self.starter)
            self.reset_board()
        elif self.tile[btn_id].cget('bg') == 'white':
            self.tile[btn_id].config(bg=self.user.colour, activebackground=self.user.colour)
            self.turns += 1
            if not self.check_end():
                self.computer_turn()

    def computer_turn(self):
        """
        Perform the computers turn in the game
        """
        selection = random.randint(0, 8)
        while self.tile[selection].cget('bg') != 'white':
            selection = random.randint(0, 8)
        self.tile[selection].config(bg=self.computer.colour, activebackground=self.computer.colour)
        self.turns += 1
        self.check_end()

    def check_end(self):
        """
        Check whether the game has ended, and complete necessary actions if so.

        Returns (boolean) : If the game has ended, return True
        """
        columns = [0,1,2]
        rows = [0,3,6]
        diagonals = [0,2]

        winner = self.search(columns, 3) or self.search(rows, 1) or self.search(diagonals,None,True)
        streak = 'Current Streak: '
        if winner:       
            if self.streak[0] == winner:
                self.streak[1] += 1
            else:
                self.streak[0] = winner
                self.streak[1] = 1
            self._win.config(text = streak+'{} to {}'.format(self.streak[1],self.streak[0]))    
        elif self.turns > 8:
            self.streak = ['None', 0]
            self._win.config(text = streak+self.streak[0])
        if winner or self.turns > 8:
            self._replay.config(text= 'Click board to replay')
            self.finished = True
            return True
                                                        
    def search(self, axis, increment, diagonal=False):
        """
        Generic search to check if a winner exists.

        Paramters:
            axis (list): the initial values of each row/ column
            increment (integer/ None ): the amount to increment by in each loop (None if diagonal)
            diagonal (boolean): check whether this a diagonal search

        Returns (string): winner of the game (if exists) 
        """
        win=False
        for a in axis:
            if not diagonal:
                if self.tile[a].cget('bg') == self.tile[a+increment*1].cget('bg') == self.tile[a+increment*2].cget('bg') != 'white':
                    win= True
            else:
                if self.tile[0+a].cget('bg') == self.tile[4].cget('bg') == self.tile[8-a].cget('bg') != 'white':
                    win= True
            if win: 
                if self.tile[a].cget('bg') == self.user.colour:
                    return 'Player'
                else:
                    return 'Computer'

    def create_popup(self, player):
        """
        Create a popup for user to input name.

        Parameters:
            player (string): The name of the player
        """
        self._popup = Popup()
        self._popup.label.config(text='Please enter a colour for '+player.name)
        self._popup.title = 'Colour Entry'
        self._popup.bind('<Return>', partial(self.change_colour, player))
        self._popup.button.config(command= partial(self.change_colour, player))

    def change_colour(self, player, event=None):
        """
        Check that the user has input a valid colour and change it if so.

        Parameters:
            player (Player): The player which will have colour changed
            event (Event): parameter to accept event handler from <Return> keypress
        """
        colour = self._popup.entry.get()
        if (colour.lower() == 'white')  :
            messagebox.showerror("Error", "Sorry, that is a system reserved colour")
        elif colour.lower() in [self.user.colour, self.computer.colour]:
            messagebox.showerror("Error", "Sorry, the colour \"{}\" is already in use".format(colour))
        else:
            try :
                for widget in self.tile:
                        if widget.cget('bg') == player.colour:
                            widget.config(bg=colour, activebackground=colour)
                player.colour=colour
                self._popup.destroy()
            except tk.TclError:
                messagebox.showerror("Error", '\'' + colour + "\' is not a valid colour")
                
class Player(object):
    def __init__(self, colour, player):
        self.colour = colour
        self.name = player

class App(object):
    """
    Class to create window for app.
    """
    
    def __init__(self, master):
        """
        Initialise widgets.
        """
        self.master= master
        self.master.title("CSSE1001 Queue")
        self.master.geometry("1050x700")
        self.master.minsize("1000","650")
        self.master.config(bg='white')
        self._header = Header(self.master)
        self._header.pack(fill=tk.X)
        self._header.config(background='light yellow')
        self.master.activeperson = []
        self._quick = QuickQuestion(self.master)
        self._long = LongQuestion(self.master)
        self._menu = tk.Menu(self.master)
        self.master.config(menu=self._menu)
        self._filemenu = tk.Menu(self._menu)
        self._menu.add_cascade(label="Game", menu=self._filemenu)
        self._filemenu.add_command(label="Play Game!", command=self.game)

    def game(self):
        """
        Create an instance of Game to play while waiting
        """
        videogame = Game()

root = tk.Tk()
app = App(root)
root.mainloop()
